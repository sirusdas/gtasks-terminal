# Google Tasks CLI

A powerful, feature-rich CLI application for Google Tasks management in Python.

## Features

- Full Google Tasks API integration with OAuth2 authentication
- Advanced filtering and search capabilities
- Context management for different task views
- Reporting and analytics
- Time tracking and Pomodoro technique integration
- Recurring tasks and dependencies
- Offline mode with synchronization
- Import/export functionality
- [Optimized Advanced Sync](https://github.com/sirusdas/gtasks-terminal/blob/main/ADVANCED_SYNC_OPTIMIZATION.md) for improved performance
- Multi-account support
- Interactive mode with keyboard navigation
- Task deduplication
- Rich terminal UI with color coding

## Installation

```bash
pip install gtasks-cli
```

Or for development/local installation:

```bash
pip install -r requirements.txt
```

## Usage

After installation, you can use the `gtasks` command:

```bash
gtasks --help
```

For development, you can run directly:

```bash
python -m gtasks_cli.main --help
```

Common commands:

```bash
# Enter interactive mode for a rich, keyboard-driven interface
gtasks interactive

# List tasks
gtasks list

# Add a new task
gtasks add "Buy groceries" --due "tomorrow"

# Mark task as done
gtasks done <task-id>

# Sync with Google Tasks
gtasks sync
```

## Development

This project follows a modular architecture with clear separation of concerns:
- **CLI Layer**: Command-line interface using Click framework
- **Core Layer**: Business logic for task and tasklist management
- **Integration Layer**: Google Tasks API integration and authentication
- **Storage Layer**: Local caching and configuration management
- **Reporting Layer**: Analytics and reporting functionality

## License

MIT